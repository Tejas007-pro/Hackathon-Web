const protect = require('./auth');

const adminOrStaff = (req, res, next) => {
  // Use the protect middleware first
  protect(req, res, () => {
    // Check the user's role
    if (req.user && (req.user.role === 'admin' | req.user.role === 'staff')) {
      next();
    } else {
      res.status(403).json({ message: 'Access denied. Requires Admin/Staff role.' });
    }
  });
};

module.exports = adminOrStaff;