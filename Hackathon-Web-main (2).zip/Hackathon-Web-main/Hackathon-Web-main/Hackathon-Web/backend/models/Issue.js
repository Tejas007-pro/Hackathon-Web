const mongoose = require('mongoose');

// Define a sub-schema for the history log entries (Transparency Feature)
const historyLogSchema = new mongoose.Schema({
  timestamp: { type: Date, default: Date.now },
  actor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  action_type: { 
    type: String, 
    enum: [
      'REPORTED',
      'STATUS_CHANGED',
      'ASSIGNED',
      'COMMENT_ADDED',
      'RESOLVED',
      'PENDING_VALIDATION'
    ],
    required: true
  },
  comment: { type: String }
}, { _id: false });

const issueSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  category: { type: String, required: true }, 
  status: { type: String, enum: ['reported', 'in_progress', 'resolved', 'pending_validation'], default: 'reported' },

  // Geospatial data (Crucial for Hotspot Maps)
  location: {
    type: { type: String, enum: ['Point'], default: 'Point' },
    coordinates: { type: [Number], index: '2dsphere', required: true }, // [longitude, latitude]
  },
  
  photo_url: { type: String },
  reporter_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  assigned_to_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, 

  history: [historyLogSchema], // Array of history log entries
  
  blockchain_tx: { type: String }, 
}, { timestamps: true });

issueSchema.index({ location: '2dsphere' });

const Issue = mongoose.model('Issue', issueSchema);
module.exports = Issue;
