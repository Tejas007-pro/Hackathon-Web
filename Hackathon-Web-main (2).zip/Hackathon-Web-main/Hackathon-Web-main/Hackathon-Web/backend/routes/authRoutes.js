const express = require('express');
const router = express.Router();
// Correct relative path from 'routes' folder to 'controllers' folder
const { registerUser, loginUser, getUserProfile } = require('../controllers/authController'); 
const protect = require('../middleware/auth');

// POST /api/v1/auth/register (Public - Login/Register)
router.post('/register', registerUser);

// POST /api/v1/auth/login (Public - Login/Register)
router.post('/login', loginUser);

// GET /api/v1/auth/profile (Protected - Profile Tab)
router.get('/profile', protect, getUserProfile);

module.exports = router;
