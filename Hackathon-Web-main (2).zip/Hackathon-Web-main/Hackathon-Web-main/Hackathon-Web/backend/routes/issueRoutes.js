const express = require('express');
const router = express.Router();
const { getAllIssues, reportNewIssue, getAdminIssues, updateIssueStatus } = require('../controllers/issueController');
const protect = require('../middleware/auth');
const adminOrStaff = require('../middleware/adminAuth');

// Public - Get list of issues
router.get('/', getAllIssues);

// Protected - Report a new issue
router.post('/', protect, reportNewIssue);

// Admin/Staff routes

// Admin dashboard - get list of issues
router.get('/admin', adminOrStaff, getAdminIssues);

// Admin route - update issue status or assignment
router.patch('/admin/:id', adminOrStaff, updateIssueStatus);

module.exports = router;
