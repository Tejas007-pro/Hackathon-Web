const Issue = require('../models/Issue');

// Public: Get all issues for home feed
exports.getAllIssues = async (req, res) => {
  try {
    const issues = await Issue.find().sort({ createdAt: -1 });
    res.status(200).json(issues);
  } catch (error) {
    console.error('Error fetching issues:', error);
    res.status(500).json({ message: 'Error fetching issues.' });
  }
};

// Protected: Report a new issue
exports.reportNewIssue = async (req, res) => {
  try {
    const newIssue = new Issue(req.body);
    const savedIssue = await newIssue.save();
    res.status(201).json(savedIssue);
  } catch (error) {
    console.error('Issue reporting error:', error);
    res.status(500).json({ message: 'Error creating new issue report.' });
  }
};

// Admin: Get issues for admin dashboard
exports.getAdminIssues = async (req, res) => {
  try {
    const adminIssues = await Issue.find().sort({ status: 1, updatedAt: -1 });
    res.status(200).json(adminIssues);
  } catch (error) {
    console.error('Error fetching admin issues:', error);
    res.status(500).json({ message: 'Error fetching admin issues.' });
  }
};

// Admin: Update issue status or assignment
exports.updateIssueStatus = async (req, res) => {
  try {
    const issueId = req.params.id;
    const updateData = req.body;

    const updatedIssue = await Issue.findByIdAndUpdate(issueId, updateData, {
      new: true,
      runValidators: true,
    });

    if (!updatedIssue) {
      return res.status(404).json({ message: 'Issue not found.' });
    }

    res.status(200).json(updatedIssue);
  } catch (error) {
    console.error('Error updating issue:', error);
    res.status(500).json({ message: 'Error updating issue.' });
  }
};
