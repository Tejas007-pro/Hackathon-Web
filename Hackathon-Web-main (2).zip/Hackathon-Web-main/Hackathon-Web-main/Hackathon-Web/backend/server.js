const express = require('express');
const connectDB = require('./config/db'); 
const dotenv = require('dotenv');

// Load environment variables from .env file at project root
dotenv.config({ path: './.env' }); 

// Initialize Express app
const app = express();

// Connect to MongoDB database
connectDB(); 

// Middleware to parse JSON bodies
app.use(express.json());

// Import Routes
const authRoutes = require('./routes/authRoutes'); 
const issueRoutes = require('./routes/issueRoutes'); 

// Base route for sanity check
app.get('/', (req, res) => {
    res.send('Civic Intelligence Platform API is running.');
});

// Use routes with API versioning prefix
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/issues', issueRoutes);

// Start server using port from env or default to 5000
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle unhandled promise rejections (like DB connection failure)
process.on('unhandledRejection', (err, promise) => {
  console.error(`Error: ${err.message}`);
  // Close server and exit process
  server.close(() => process.exit(1));
});
